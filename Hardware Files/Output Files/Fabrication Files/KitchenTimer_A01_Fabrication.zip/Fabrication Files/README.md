# KiKadProjectTemplate
Template for KiKad Hardware Projects
